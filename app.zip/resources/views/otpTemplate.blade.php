<!DOCTYPE html>
<html>
<head>
    <title>OTP Email</title>
</head>
<body>
    <h1>OTP Verification</h1>
    <p>Your OTP is: <strong>{{ $otp }}</strong></p>
    <p>Please use this OTP to verify your account.</p>
</body>
</html>
