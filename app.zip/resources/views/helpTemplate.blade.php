<!DOCTYPE html>
<html>
<head>
    <title>Help Email</title>
</head>
<body>
    <h1>Help Email</h1>
    <p>Your Help is: <strong>{{ $description }}</strong></p>

</body>
</html>
