<!DOCTYPE html>
<html>
<head>
    <title>User Credentials</title>
</head>
<body>
    <h1>User Credentials</h1>
    <p>Your credentials are:</p>
    <p>Email: {{ $email }}</p>
    <p>Password: {{ $password }}</p>
    <p>Please use this login to your account.</p>
</body>
</html>
