<!DOCTYPE html>
<html>
<head>
    <title>User Credentials</title>
</head>
<body>
    <h1>User Credentials</h1>
    <p>Your credentials are:</p>
    <p>Email: <?php echo e($email); ?></p>
    <p>Password: <?php echo e($password); ?></p>
    <p>Please use this login to your account.</p>
</body>
</html>
<?php /**PATH G:\Xampp\htdocs\myRide\resources\views/passwordTemplate.blade.php ENDPATH**/ ?>