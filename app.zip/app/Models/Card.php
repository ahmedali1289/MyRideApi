<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Card extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'card_no',
        'date',
        'ccv',
        'user_id',
        'type',
    ];

    public function rides()
    {
        return $this->hasMany(Ride::class);
    }
}
